# Results

## Local inference, 2026-10-05

The recorded synthetic, sequential Winnow-12B run contains **66 attempts**:
**60 measured** (six workloads, five prefix-cold and five warm samples each)
and **six setup attempts**. All 66 passed the recorded answer/schema and issue
checks, with **zero failures**, including setup. This does not establish semantic
accuracy or general application reliability.

[Raw strict Report](../results/local-performance/results.json) and
[full local report](../results/local-performance/report.md) retain every attempt.
The plot validates the current `benchmarks.inference.Report`, checks repetition
coverage and cache evidence, and recomputes summaries from raw samples. It rejects
incomplete or failed runs rather than silently charting a valid subset.

![Local latency medians and min/max endpoints](../results/local-performance/latency.png)

[Vector SVG](../results/local-performance/latency.svg). Markers show median client
wall latency, capped bars show the full min/max range, and the axis is logarithmic.
Each row labels question count and image dimensions and shows valid/attempted and
failed counts. The first prefix-cold **7.653479 s** observation remains included.
With five samples per regime, sample p95 equals the maximum; these are not
confidence intervals or reliable tail estimates.

Prefix-cold means prefix reuse was disabled, not model-start or filesystem-cache
cold. Every warm sample reported `cache_hit=true` and `prefix_reused_tokens>0`.
Setup remains in the attempt/failure denominator and is excluded from latency.
These measurements do not isolate a causal cache effect.

The recorded host was **Apple M2 Ultra, 64 GiB**, with Python 3.13.9 on arm64 macOS.
Model discovery reported **Q8_0, context 8192**; the operator declared Metal,
**F16 KV**, one parallel slot, and a loaded vision projector. Operator-reported
context for this run included approximately **6457.56 MiB host-wide swap** and
concurrent presentation/native-forward work. Those conditions were not isolated
or attributed to individual requests.

Across all 60 measured samples, the median wall-minus-HTTP-request interval was
**0.288 ms** (range **0.133–0.448 ms**); wall-minus-provider-native time was
**2.635 ms** (range **2.061–5.825 ms**). These paired timing differences describe
observed boundaries, not isolated overhead causes or simulator action latency.

Across all 66 attempts, 1430 whole-process resource observations recorded peak
RSS **1,565,152 KiB / 1.493 GiB**. Separately, provider diagnostics reported
backend allocation **14,664,105,984–14,668,742,656 bytes / 13.657–13.661 GiB**
against a backend budget of **55,662,788,608 bytes / 51.840 GiB**. Process RSS and
backend/device accounting are different views; do not add them or infer a small
model footprint from RSS. These are sampled observations, not per-request
allocation or capacity proof. Energy was not measured.

All **66 attempts were unpriced**: reported total cost remains **unknown/null**,
not zero. Native episode comparisons require the separate frozen 105-episode
matrix and are outside this local inference section.

Regenerate from the repository root with optional, ephemeral Matplotlib:

```sh
rtk proxy uv run --no-sync --with matplotlib python -B -m benchmarks.plot_local \
  --input results/local-performance/results.json \
  --output-dir results/local-performance
```

Both paths are CLI arguments. Add `--linear` for a linear latency axis. The
library's permanent runtime dependencies are unchanged.
